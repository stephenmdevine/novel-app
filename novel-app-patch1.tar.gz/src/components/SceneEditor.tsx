import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import CharacterCount from '@tiptap/extension-character-count';
import { useEffect, useRef, useState } from 'react';
import { EntityTag } from '../lib/EntityTag';
import type { Tag, Scene } from '../types';
import './SceneEditor.css';

interface SceneEditorProps {
  scene: Scene;
  tags: Tag[];
  onChange: (html: string, wordCount: number) => void;
  onCreateTag: (name: string, type: Tag['type']) => Tag;
}

export default function SceneEditor({ scene, tags, onChange, onCreateTag }: SceneEditorProps) {
  const [tagMenuOpen, setTagMenuOpen] = useState(false);
  // Capture the editor selection range BEFORE the menu opens (clicking the
  // button blurs the editor and loses the selection otherwise)
  const savedSelection = useRef<{ from: number; to: number } | null>(null);

  const editor = useEditor({
    extensions: [
      StarterKit,
      CharacterCount,
      EntityTag,
    ],
    content: scene.content || '<p></p>',
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      const words = editor.storage.characterCount.words();
      onChange(html, words);
    },
  });

  // Reload content when switching scenes
  useEffect(() => {
    if (editor && editor.getHTML() !== scene.content) {
      editor.commands.setContent(scene.content || '<p></p>');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scene.id]);

  if (!editor) return null;

  // Called onMouseDown on the "Tag Selection" button so selection is still
  // active (it hasn't been blurred yet by the click)
  const handleTagButtonMouseDown = (e: React.MouseEvent) => {
    e.preventDefault(); // prevents editor blur entirely
    const { from, to } = editor.state.selection;
    if (from === to) {
      alert('Select some text in the editor first, then click "Tag Selection".');
      return;
    }
    savedSelection.current = { from, to };
    setTagMenuOpen((o) => !o);
  };

  const applyTag = (tag: Tag) => {
    if (!savedSelection.current) return;
    const { from, to } = savedSelection.current;
    editor
      .chain()
      .focus()
      .setTextSelection({ from, to })
      .setEntityTag(tag.id)
      .run();
    savedSelection.current = null;
    setTagMenuOpen(false);
  };

  const removeTag = () => {
    editor.chain().focus().unsetEntityTag().run();
  };

  const handleNewTag = () => {
    if (!savedSelection.current) return;
    const { from, to } = savedSelection.current;
    const selectedText = editor.state.doc.textBetween(from, to);
    if (!selectedText) {
      alert('No text was selected.');
      return;
    }
    const type = prompt('Tag type (character / location / item / other):', 'character') as
      | Tag['type']
      | null;
    if (!type) return;
    const tag = onCreateTag(selectedText, type);
    applyTag(tag);
  };

  const words = editor.storage.characterCount.words();
  const chars = editor.storage.characterCount.characters();

  return (
    <div className="scene-editor">
      <div className="editor-toolbar">
        <button
          onMouseDown={(e) => { e.preventDefault(); editor.chain().focus().toggleBold().run(); }}
          className={editor.isActive('bold') ? 'active' : ''}
        >B</button>
        <button
          onMouseDown={(e) => { e.preventDefault(); editor.chain().focus().toggleItalic().run(); }}
          className={editor.isActive('italic') ? 'active' : ''}
        >I</button>
        <button
          onMouseDown={(e) => { e.preventDefault(); editor.chain().focus().toggleHeading({ level: 2 }).run(); }}
          className={editor.isActive('heading', { level: 2 }) ? 'active' : ''}
        >H2</button>
        <div className="toolbar-divider" />
        <div className="tag-control">
          <button onMouseDown={handleTagButtonMouseDown}>Tag Selection</button>
          {tagMenuOpen && (
            <div className="tag-menu">
              {tags.length === 0 && (
                <div className="tag-menu-item tag-menu-new" onMouseDown={handleNewTag}>
                  + New tag from selection
                </div>
              )}
              {tags.map((t) => (
                <div key={t.id} className="tag-menu-item" onMouseDown={() => applyTag(t)}>
                  <span className={`tag-dot tag-${t.type}`} /> {t.name}
                </div>
              ))}
              {tags.length > 0 && (
                <div className="tag-menu-item tag-menu-new" onMouseDown={handleNewTag}>
                  + New tag from selection
                </div>
              )}
            </div>
          )}
        </div>
        <button onMouseDown={(e) => { e.preventDefault(); removeTag(); }}>Remove Tag</button>
        <div className="toolbar-spacer" />
        <div className="word-count">
          {words} words &middot; {chars} chars
        </div>
      </div>
      <EditorContent editor={editor} className="editor-content" spellCheck={true} />
    </div>
  );
}
